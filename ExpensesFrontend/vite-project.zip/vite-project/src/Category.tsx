import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function Category() {
  const navigate = useNavigate();
  const [values, setValues] = useState<any[]>([]);
  const [refresh, setRefresh] = useState<boolean>(false);

  useEffect(() => {
    Load();
  }, [refresh]);

  const Load = async () => {
    debugger;
    await axios.get("https://localhost:7233/api/Categories").then((res) => {
      if (res.data) setValues(res.data);
    });
    //setId(result.data);
  };
  
   async function Delete(id:string){debugger
      await axios.delete(`https://localhost:7233/api/Categories/${id}`);
      alert("Category deleted successfullly");
      setRefresh(true)
   }

  return (
    <>
      <div className="mt-4">
        {/* <button
          onClick={() => navigate(-1)}
          className="border-2 rounded-lg ml-60 px-7 py-5 text-[17px] text-center bg-black text-white font-semibold "
        >
          Go Back
        </button> */}
        <button
          onClick={() => navigate("/addcategory")}
          className="font-thin text-[14px] ml-18 px-2 py-3 bg-blue-500 text-white rounded-lg border text-center"
        >
          <i className="text-[12px] fa-solid fa-plus"></i> Add Category
        </button>
      </div>
      <div className="p-8 ml-8 text-[14px] font-thin relative overflow-x-auto">
        <table className="w-full text-left rtl:text-right table-auto border-b border-gray-100">
          <thead className=" text-gray-700 text-middle ml-10 p-4 font-thin bg-gray-100 ">
            <tr className="">
              <th scope="col" className="px-6 py-3">
                Name
              </th>
              <th scope="col" className="px-6 py-3">
                Budget
              </th>
              <th scope="col" className="px-6 py-3">
                Type
              </th>
              <th scope="col" className="px-6 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {values?.map((val) => {
              return (
                <>
                  <tr className="">
                    <th scope="row" className="px-6 py-4 ">
                      {val.name}
                    </th>
                    <td className="px-6 py-4">{val.budgetLimit}</td>
                    <td className="px-6 py-4">{val.type}</td>
                    <td className="px-6 py-4">
                      <button onClick={() =>{ navigate(`/addcategory/${val.id}`);}}>
                        <i className="fa-solid fa-pen-to-square"></i>
                      </button>
                      <button onClick={()=>Delete(val.id)} className="ml-5">
                        <i className="fa-solid fa-trash"></i>
                      </button>
                    </td>
                  </tr>
                </>
              );
            })}
          </tbody>
        </table>
      </div>
    </>
  );
}

export default Category;
