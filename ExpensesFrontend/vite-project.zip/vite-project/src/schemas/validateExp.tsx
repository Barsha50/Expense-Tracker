

// const basicSchema = yup.object().shape({
//     title: yup.string().min(2).required("Please enter title"),
//     amount: yup.number().positive().integer().required("Please enter amount"),
//     payment: yup.string().required("Please enter payment mode"),
//     categoryId : yup.string().required("Please eneter a valid category"),
// })
// export default basicSchema;