function Navbar() {
  return (
    <div className='bg-blue-500 text-white text-[16px] flex  border-b border-gray-100 p-3 ml-15 font-semibold'>
        Expense Tracker
    </div>
  )
}

export default Navbar