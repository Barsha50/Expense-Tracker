import { BrowserRouter, Route, Routes } from "react-router-dom";
// import Category from "./Category"
import Expense from "./Expense";
import AddCategory from "./components/AddCategory";
import AddExpense from "./components/AddExpense";
import Sidebar from "./components/SidePanel";
import Navbar from "./components/Navbar";
import Category from "./Category";
// import AddExpense from "./components/AddExpense"
function App() {
  return (
    <BrowserRouter>
      <div className="flex" style={{width:"100%"}}>
       <div style={{width:"10%", zIndex:100}}> <Sidebar /></div>
        <div className="grow h-full text-black" style={{width:"90%"}}>
          <Navbar />
          {/* <div className="grow h-full ml-2">
            <Expense />
          </div> */}
       <div style={{width:"100%"}}>
        <Routes>
          <Route path="/" element={<Expense />} />
          <Route path="/category" element={<Category/>}/>
          <Route path="/addcategory" element={<AddCategory />} />
          <Route path="/addcategory/:id" element={<AddCategory />} />
          <Route path="/addexpense/:id" element={<AddExpense />} />
          <Route path="/addexpense" element={<AddExpense />} />
        </Routes>
         </div>
        {/* <Routes>
      <Route path="/" element={ <Sidebar/>} />
      
      <Route path="/addcategory" element={<AddCategory/>}/>
      <Route path="/addcategory/:id" element={<AddCategory/>}/>
      <Route path="/addexpense/:id" element={<AddExpense/>}/>
      <Route path="/addexpense" element={<AddExpense/>}/>
      <Route path="/category" element={<Category/>}/>
      <Route path="/expense" element={<Expense/>}/>
    </Routes> */} 
    </div>
      </div>
    </BrowserRouter>
  );
}

export default App;
